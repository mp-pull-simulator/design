package mapper;

import au.com.bytecode.opencsv.CSVReader;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class SellerChcekuser {
    private static WebDriver d;

    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.edge.driver", "D:\\msedgedriver.exe"); // replace with your geckodriver.exe csv file location
        d = new EdgeDriver();
    }

    @Test
    public void test() throws Exception {
        String csvFilePath = "D:\\Test\\seller_login.csv";
        BufferedReader br = null;
        CSVReader reader = null;
        String[] col;
        boolean isFirstLine = true;  // 是否是第一行
        List<String[]> cols = new ArrayList<>();

        try {
            br = new BufferedReader(new InputStreamReader(new FileInputStream(csvFilePath), Charset.forName("GBK")));
            reader = new CSVReader(br);

            while ((col = reader.readNext()) != null) {
                if (isFirstLine) {  // 如果是第一行，忽略
                    isFirstLine = false;
                    continue;
                }
                cols.add(col);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null)
                    reader.close();
                if (br != null)
                    br.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Print the data from CSV file
//        for (String[] r : cols) {
//            for (String s : r) {
//                System.out.print(s + "\t");
//            }
//            System.out.println();
//        }
        d.get("http://localhost:8083/");

        // Enter credentials and submit
        for (String[] r : cols) {

            System.out.print(r.length);
            d.findElement(By.id("btn1")).click();
            Thread.currentThread().sleep(3000);
            d.findElement(By.id("id1")).clear();
            d.findElement(By.id("pwd1")).clear();
            d.findElement(By.id("id1")).sendKeys(r[0]);
            d.findElement(By.id("pwd1")).sendKeys(r[1]);
            Thread.currentThread().sleep(1000);
            d.findElement(By.className("login1")).click();
            d.findElement(By.id("seller1")).click();
            Thread.currentThread().sleep(3000);
            d.findElement(By.id("seller2")).click();
            d.findElement(By.id("ifo1")).click();

            d.switchTo().defaultContent();
            Thread.sleep(3000);

            // Do some further testing or validation here
        }

    }

    @After
    public void tearDown() throws Exception {
        d.quit();
    }
}
