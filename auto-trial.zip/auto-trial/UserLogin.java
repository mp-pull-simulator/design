package rjgc.mall.mapper;

import au.com.bytecode.opencsv.CSVReader;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class UserLogin {
    private static WebDriver d;

    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.edge.driver", "D:\\msedgedriver.exe"); // replace with your geckodriver.exe csv file location
        d = new EdgeDriver();
    }

    @Test
    public void test() throws Exception {
        String csvFilePath = "D:\\Test\\user_login.csv";
        BufferedReader br = null;
        CSVReader reader = null;
        String[] col;
        boolean isFirstLine = true;  // 是否是第一行
        List<String[]> cols = new ArrayList<>();

        try {
            br = new BufferedReader(new InputStreamReader(new FileInputStream(csvFilePath), Charset.forName("GBK")));
            reader = new CSVReader(br);

            while ((col = reader.readNext()) != null) {
                if (isFirstLine) {  // 如果是第一行，忽略
                    isFirstLine = false;
                    continue;
                }
                cols.add(col);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null)
                    reader.close();
                if (br != null)
                    br.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Print the data from CSV file
//        for (String[] r : cols) {
//            for (String s : r) {
//                System.out.print(s + "\t");
//            }
//            System.out.println();
//        }


        // Enter credentials and submit
        for (String[] r : cols) {
            d.get("http://localhost:8083/");
            System.out.print(r.length);
            d.findElement(By.className("btn")).click();
            Thread.currentThread().sleep(3000);
            d.findElement(By.id("id")).clear();
            d.findElement(By.id("pwd")).clear();
            d.findElement(By.id("id")).sendKeys(r[0]);
            d.findElement(By.id("pwd")).sendKeys(r[1]);

            Thread.currentThread().sleep(3000);
            d.findElement(By.className("class14")).click();

            d.switchTo().defaultContent();
            Thread.sleep(3000);

            // Do some further testing or validation here
        }

    }

    @After
    public void tearDown() throws Exception {
        d.quit();
    }
}
