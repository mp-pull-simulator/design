package rjgc.mall.mapper;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SellerLogin {
    public static void main(String[] args) throws InterruptedException {
        String shareUrl = "http://localhost:8083/";
        System.setProperty("webdriver.edge.driver", "D:\\msedgedriver.exe");
        WebDriver driver = new EdgeDriver();
        driver.get(shareUrl);
        WebDriverWait wait = new WebDriverWait(driver, 5);
        wait.until(new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver d) {
                boolean loadcomplete = d.findElement(By.tagName("body")).isDisplayed();
                return loadcomplete;
            }
        });
        driver.findElement(By.className("btn1")).click();
        Thread.currentThread().sleep(3000);
        driver.findElement(By.id("id1")).sendKeys("123456w");
        driver.findElement(By.id("pwd1")).sendKeys("123456w");
        Thread.currentThread().sleep(3000);
        driver.findElement(By.className("login1")).click();
    }
}
